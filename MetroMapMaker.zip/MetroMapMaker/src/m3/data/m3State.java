/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m3.data;

/**
 *
 * @author aaronsuen
 */
public enum m3State {
    SELECTING_SHAPE,
    DRAGGING_SHAPE,
    STARTING_LINE,
    ADDING_STATION,
    ADDING_STATION_TO_LINE,
    STARTING_IMAGE,
    ADDING_LABEL,
    SIZING_SHAPE,
    DRAGGING_NOTHING,
    SIZING_NOTHING
}
